import cv2 as cv

img = cv.imread('anh_goc.jpg', cv.IMREAD_GRAYSCALE)

cv.imshow("anh chuyen sang xam", img)

# đợi ảnh
cv.waitKey(0)
cv.destroyAllWindows()

#lưu ảnh
img_new = cv.imwrite("anh_xam.jpg", img)
