import cv2 as cv
import numpy as np

img = cv.imread('anh_goc.jpg', cv.IMREAD_GRAYSCALE)

if img is None:
    print("lỗi ảnh")
else:
    print(f"Kích thước ma trận ảnh là : {img.shape}")
    print(img[::])